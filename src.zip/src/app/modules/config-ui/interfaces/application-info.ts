export interface ApplicationInfo {
    appDesc: string;
    appId: number;
    appName: string;
    dcId: number;
    dcTopoAssocId: number;
    topoId: number;
    topoName: string;
    userName: string;
}