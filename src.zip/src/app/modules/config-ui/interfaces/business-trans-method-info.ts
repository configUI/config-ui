export interface BusinessTransMethodInfo {
    argumentIndex : number;
    btMethodId : number;
    enableArgumentType : boolean;
    fqm : string;
    returnType : string;
}