export interface EntityInfo {
    dcId: number;
    id: number;
    name: string;
    topology: string;
    timestamp: string;
}