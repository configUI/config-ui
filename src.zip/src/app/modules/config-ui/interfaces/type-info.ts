import {EntityInfo} from './entity-info';

export interface TypeInfo{
    id: number;
    type: string;
    value: EntityInfo[]
}