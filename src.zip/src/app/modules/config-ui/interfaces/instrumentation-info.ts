export interface BackendInfo {
    backendTypeName: string;
    backendTypeId: number;
}

export interface BackendTableInfo {
    type: string;
    detail: string;
}