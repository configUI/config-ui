

export interface KeywordsInfo {
     defaultValue: string;
     assocId: number;
     max: string;
     keyId: number;
     min: string;
     value: string;
}



