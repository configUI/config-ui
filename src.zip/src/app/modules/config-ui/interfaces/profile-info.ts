export interface ProfileInfo{
    profileDesc: string;
    profileName: string;
    profileId: number;
    parentProfileId: number;
}