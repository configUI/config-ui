export interface TableField {
    field: string;
    header: string;
}
