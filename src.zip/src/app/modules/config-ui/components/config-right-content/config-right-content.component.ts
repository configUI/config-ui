import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-right-content',
  templateUrl: './config-right-content.component.html',
  styleUrls: ['./config-right-content.component.css']
})
export class ConfigRightContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
