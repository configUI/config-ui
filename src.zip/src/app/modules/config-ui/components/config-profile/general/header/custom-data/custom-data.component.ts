import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-data',
  templateUrl: './custom-data.component.html',
  styleUrls: ['./custom-data.component.css']
})
export class CustomDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
