import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-java-method',
  templateUrl: './java-method.component.html',
  styleUrls: ['./java-method.component.css']
})
export class JavaMethodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
