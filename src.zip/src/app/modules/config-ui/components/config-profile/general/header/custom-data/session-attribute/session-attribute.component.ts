import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-session-attribute',
  templateUrl: './session-attribute.component.html',
  styleUrls: ['./session-attribute.component.css']
})
export class SessionAttributeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
