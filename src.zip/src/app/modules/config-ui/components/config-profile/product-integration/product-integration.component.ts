import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-integration',
  templateUrl: './product-integration.component.html',
  styleUrls: ['./product-integration.component.css']
})
export class ProductIntegrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
