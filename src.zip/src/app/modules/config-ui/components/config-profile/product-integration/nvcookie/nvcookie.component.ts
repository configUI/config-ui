import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nvcookie',
  templateUrl: './nvcookie.component.html',
  styleUrls: ['./nvcookie.component.css']
})
export class NVCookieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
