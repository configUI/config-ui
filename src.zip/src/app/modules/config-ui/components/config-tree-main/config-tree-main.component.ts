import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-tree-main',
  templateUrl: './config-tree-main.component.html',
  styleUrls: ['./config-tree-main.component.css']
})
export class ConfigTreeMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
