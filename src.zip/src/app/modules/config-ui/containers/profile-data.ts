export class ProfileData {
    profileName:string;
    profileDesc:string;
    parentProfileId:number;
    profileId:number;
}
