export class HomeData {

}