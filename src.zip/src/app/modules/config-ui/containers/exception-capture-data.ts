export class ExceptionData
{
    instrumentException : boolean;
    exceptionTrace : boolean;
    exceptionTraceDepth : string;
    exceptionType : "unhandled";
}