export class KeywordData {
    assocId: number;
    defaultValue: number;
    keyId: number;
    max: number;
    min: number;
    value: number | string;
}

export class KeywordList{
    
}
